from .model_solution import ModelSolution
from .multi_solution import MultiSolution, DynamicSolution, KOSolution

# TODO: Can simulation results, EA results and other solutions be moved here?
#  If so, some objects and modules might have to be refactored.
